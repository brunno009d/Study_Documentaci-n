-- 1. Tablas Base
CREATE TABLE "student" (
  "id" uuid PRIMARY KEY REFERENCES auth.users (id) ON DELETE CASCADE,
  "full_name" varchar
);

CREATE TABLE "curriculum" (
  "id" SERIAL PRIMARY KEY,
  "student_id" uuid REFERENCES "student" ("id"),
  "name" varchar,
  "institution" varchar,
  "career" varchar,
  "total_credits" integer,
  "total_semester" integer
);

-- 2. Malla Curricular
CREATE TABLE "subjects" (
  "id" SERIAL PRIMARY KEY,
  "curriculum_id" integer REFERENCES "curriculum" ("id"),
  "name" varchar,
  "code" varchar,
  "credits" smallint,
  "semester_number" smallint,
  "area_type" varchar
);

CREATE TABLE "student_subjects" (
  "id" SERIAL PRIMARY KEY,
  "student_id" uuid REFERENCES "student" ("id"),
  "subject_id" integer REFERENCES "subjects" ("id"),
  "status" varchar -- 'aprobado', 'cursando', 'pendiente' [cite: 165]
);

CREATE TABLE "subject_prerequisite" (
  "id" SERIAL PRIMARY KEY,
  "subject_id" integer REFERENCES "subjects" ("id"),
  "prerrequisite_id" integer REFERENCES "subjects" ("id")
);

-- 3. Gestión Académica (Notas, Materiales y Apuntes)
CREATE TABLE "evaluation" (
  "id" SERIAL PRIMARY KEY,
  "subject_id" integer REFERENCES "subjects" ("id"),
  "name" varchar,
  "weight" decimal, -- Ponderación para cálculo automático 
  "grade" decimal,
  "is_simulation" boolean DEFAULT false
);

CREATE TABLE "notes" (
  "id" SERIAL PRIMARY KEY,
  "student_id" uuid REFERENCES "student" ("id"),
  "subject_id" integer REFERENCES "subjects" ("id"), -- Puede ser NULL para notas generales 
  "title" varchar,
  "content_text" text
);

CREATE TABLE "material" (
  "id" SERIAL PRIMARY KEY,
  "subject_id" integer REFERENCES "subjects" ("id"),
  "file_name" varchar,
  "bucket_url" varchar -- Enlace a Supabase Storage [cite: 263, 299]
);

-- 4. Calendario y Organización
CREATE TABLE "calendar" (
  "id" SERIAL PRIMARY KEY,
  "student_id" uuid REFERENCES "student" ("id"),
  "title" varchar
);

CREATE TABLE "calendar_event" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  "calendar_id" integer REFERENCES "calendar" ("id"),
  "title" varchar,
  "description" varchar,
  "start_datetime" timestamp,
  "end_datetime" timestamp,
  "event_type" varchar,
  "color_hex" varchar
);

-- 5. Sistema de Etiquetas (Categorización 360)
CREATE TABLE "tags" (
  "id" SERIAL PRIMARY KEY,
  "name" varchar,
  "color_hex" varchar
);

CREATE TABLE "note_tags" (
  "note_id" integer REFERENCES "notes" ("id"),
  "tag_id" integer REFERENCES "tags" ("id"),
  PRIMARY KEY ("note_id", "tag_id")
);

CREATE TABLE "materials_tags" (
  "material_id" integer REFERENCES "material" ("id"),
  "tag_id" integer REFERENCES "tags" ("id"),
  PRIMARY KEY ("material_id", "tag_id")
);

-----------------------------------
--- PRIMERA MODIFICACION ----------
-----------------------------------

-- Alteracion de tabla notas. ahora se agrega una tabla categorias

-- 1. Crear la tabla de categorías sin el flag de simulación
CREATE TABLE "evaluation_categories" (
  "id" SERIAL PRIMARY KEY,
  "subject_id" integer REFERENCES "subjects" ("id") ON DELETE CASCADE,
  "parent_category_id" integer REFERENCES "evaluation_categories" ("id") ON DELETE CASCADE,
  "name" varchar NOT NULL,
  "weight" decimal NOT NULL -- Peso relativo (ej: 0.6 para presentación, 0.4 para examen)
);

-- 2. Ajustar la tabla de notas para que use la categoría
-- Nota: Si la tabla 'evaluation' ya existe, primero quitamos la columna vieja y añadimos la nueva
ALTER TABLE "evaluation" DROP COLUMN IF EXISTS "subject_id";
ALTER TABLE "evaluation" ADD COLUMN "category_id" integer REFERENCES "evaluation_categories" ("id") ON DELETE CASCADE;

-- IMPORTANTE: Asegúrate de que 'is_simulation' siga existiendo en la tabla 'evaluation'
-- porque ahí es donde el alumno marcará qué nota es real y cuál es proyectada.

----------------------------------
--- Segunda modificacion ---------
----------------------------------

-- 1. Relación opcional en eventos
ALTER TABLE "calendar_event" 
ADD COLUMN "evaluation_id" integer REFERENCES "evaluation" ("id") ON DELETE SET NULL;

-- 2. Tabla de recordatorios optimizada
CREATE TABLE "event_reminders" (
  "id" SERIAL PRIMARY KEY,
  "student_id" uuid NOT NULL REFERENCES "student" ("id") ON DELETE CASCADE,
  "event_id" uuid NOT NULL REFERENCES "calendar_event" ("id") ON DELETE CASCADE,
  "reminder_at" timestamp with time zone NOT NULL,
  "sent" boolean DEFAULT false
);

