-- Función que inserta el perfil del estudiante
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.student (id, full_name)
  VALUES (
    new.id, 
    COALESCE(new.raw_user_meta_data->>'full_name', 'Estudiante Nuevo')
  );
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- El disparador que activa la función anterior
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- QUe la tabla student_subjects tenga ids unicos irrepetibles
ALTER TABLE "student_subjects" ADD CONSTRAINT unique_student_subject UNIQUE ("student_id", "subject_id");

-- Index para el Worker de notificaciones
CREATE INDEX idx_reminders_pending ON "event_reminders" (reminder_at) WHERE sent = false;